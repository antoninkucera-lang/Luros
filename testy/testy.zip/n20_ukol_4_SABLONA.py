from typing import List

# ======================================================================
# ÚKOL 4: Filtrování dat a List Comprehension (Lekce N03, N15)
# ======================================================================

class Zbozi:
    def __init__(self, nazev: str, cena: float):
        self.nazev = nazev
        self.cena = cena

    def __str__(self):
        return f"{self.nazev}: {self.cena:.0f} Kč"


def filtruj_a_zlevni(zbozi_list: List[Zbozi], max_cena: float, sleva_procenta: float) -> List[Zbozi]:
    """
    Vrátí nové seznam položek se slevou.
    Vybere zboží z `zbozi_list`, jejichž cena je menší nebo rovna `max_cena`.
    U vybraných položek upraví cenu podle `sleva_procenta`.
    """
    zlevnene = []
    for z in zbozi_list:
        if z.cena <= max_cena:
            z.cena = z.cena * (1 - sleva_procenta / 100)
            zlevnene.append(z)
    return zlevnene


# Testovací část pro spuštění
if __name__ == "__main__":
    sklad_zbozi = [
        Zbozi("Kniha Python", 600.0),
        Zbozi("Herní Klávesnice", 1200.0),
        Zbozi("Levná Myš", 400.0),
        Zbozi("Monitor 4K", 5000.0)
    ]

    print("--- 1. Původní Stav Zboží z databáze ---")
    for z in sklad_zbozi:
        print(z)

    print("\n--- 2. Po slevové akci: Hledáme do <1000 Kč s 20% slevou ---")
    dostupne_zlevnene = filtruj_a_zlevni(sklad_zbozi, max_cena=1000.0, sleva_procenta=20.0)

    if dostupne_zlevnene is None:
        print("Tvá funkce stále vrací starou prázdnou None hodnotu :)")
    else:
        for z in dostupne_zlevnene:
            print(z)
